import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import './style.css';

const social = [
  ['YouTube', '▶', 'https://www.youtube.com/@%D9%86%D9%88%D8%B1%D8%A7%D9%84%D9%82%D8%B1%D8%A2%D9%86%D8%A7%D9%84%D9%83%D8%B1%D9%8A%D9%85-%D8%B78%D8%B8'],
  ['Facebook', 'f', 'https://www.facebook.com/share/1DosbmtuY9/'],
  ['Instagram', '◎', 'https://www.instagram.com/noor_alquran72?mdxt=N2NpbWIxN3BweGEx'],
  ['Threads', '@', 'https://www.threads.com/@noor_alquran72'],
  ['Telegram', '➤', 'https://t.me/NoorAlQuran73'],
  ['TikTok', '♪', 'https://www.tiktok.com/@nooralqurankarim']
];
const translations = {
  ar: {home:'الرئيسية', quran:'القرآن الكريم', recitations:'التلاوات', azan:'الأذان ومواقيت الصلاة', adhkar:'الأذكار والأدعية', contact:'اتصل بنا', follow:'تابعنا', title:'نور القرآن الكريم', subtitle:'نورٌ يرافق قلبك… آياتٌ تُتلى وتُقرأ', read:'اقرأ القرآن الكريم', choose:'اختر السورة', search:'ابحث عن سورة', loading:'جارٍ تحميل القرآن الكريم…', error:'تعذر تحميل البيانات. تحقق من اتصال الإنترنت ثم أعد المحاولة.', font:'حجم الخط', smaller:'تصغير', larger:'تكبير', ayah:'آية', intro:'اقرأ القرآن الكريم كاملاً، واستمع إلى التلاوات، وتصفّح الأذكار.'},
  fr: {home:'Accueil', quran:'Le Saint Coran', recitations:'Récitations', azan:'Adhan et horaires', adhkar:'Invocations', contact:'Contact', follow:'Suivez-nous', title:'Noor Al Quran', subtitle:'La lumière du Coran dans votre quotidien', read:'Lire le Coran', choose:'Choisir une sourate', search:'Rechercher une sourate', loading:'Chargement du Coran…', error:'Impossible de charger les données. Vérifiez votre connexion.', font:'Taille du texte', smaller:'Réduire', larger:'Agrandir', ayah:'Verset', intro:'Lisez le Coran, écoutez les récitations et découvrez les invocations.'},
  en: {home:'Home', quran:'The Holy Quran', recitations:'Recitations', azan:'Adhan & prayer times', adhkar:'Adhkar & duas', contact:'Contact us', follow:'Follow us', title:'Noor Al Quran', subtitle:'Let the light of the Quran accompany you', read:'Read the Holy Quran', choose:'Choose a surah', search:'Search surah', loading:'Loading the Quran…', error:'Could not load data. Check your internet connection.', font:'Text size', smaller:'Smaller', larger:'Larger', ayah:'Verse', intro:'Read the Holy Quran, listen to recitations, and explore daily supplications.'}
};
function App() {
  const [lang, setLang] = useState(localStorage.getItem('noor-lang') || 'ar');
  const [surahs, setSurahs] = useState([]);
  const [surah, setSurah] = useState(null);
  const [query, setQuery] = useState('');
  const [fontSize, setFontSize] = useState(25);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const t = translations[lang];
  const dir = lang === 'ar' ? 'rtl' : 'ltr';

  useEffect(() => {
    localStorage.setItem('noor-lang', lang);
    document.documentElement.lang = lang;
    document.documentElement.dir = dir;
  }, [lang]);

  useEffect(() => {
    fetch('https://api.alquran.cloud/v1/surah')
      .then(r => { if (!r.ok) throw new Error(); return r.json(); })
      .then(data => setSurahs(data.data || []))
      .catch(() => setError(t.error));
  }, []);

  async function openSurah(number) {
    setLoading(true); setError(''); setSurah(null);
    try {
      const response = await fetch(`https://api.alquran.cloud/v1/surah/${number}/quran-uthmani`);
      if (!response.ok) throw new Error();
      const data = await response.json();
      setSurah(data.data);
    } catch { setError(t.error); }
    finally { setLoading(false); }
  }

  const filtered = surahs.filter(s => s.name.includes(query) || s.englishName.toLowerCase().includes(query.toLowerCase()) || String(s.number) === query);
  return <div className="app" dir={dir}>
    <header className="topbar">
      <a className="brand" href="#home"><span className="brand-mark">۞</span><span>{t.title}<small>QURAN • RECITATIONS • ADHKAR</small></span></a>
      <select aria-label="Language" value={lang} onChange={e=>setLang(e.target.value)} className="language">
        <option value="ar">العربية</option><option value="fr">Français</option><option value="en">English</option>
      </select>
    </header>
    <nav className="nav">
      <a href="#home">{t.home}</a><a href="#quran">{t.quran}</a><a href="#recitations">{t.recitations}</a><a href="#azan">{t.azan}</a><a href="#adhkar">{t.adhkar}</a><a href="#contact">{t.contact}</a>
    </nav>
    <main>
      <section className="hero" id="home">
        <div className="ornament">۞</div><p className="eyebrow">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</p>
        <h1>{t.title}</h1><p>{t.subtitle}</p>
        <a className="gold-button" href="#quran">{t.read} <span>←</span></a>
      </section>
      <section className="intro"><h2>{t.quran}</h2><p>{t.intro}</p></section>
      <section className="quran-layout" id="quran">
        <aside className="surah-panel">
          <h3>{t.choose}</h3><input value={query} onChange={e=>setQuery(e.target.value)} placeholder={t.search} />
          <div className="surah-list">{filtered.map(s=><button key={s.number} className={surah?.number===s.number?'selected':''} onClick={()=>openSurah(s.number)}><span className="number">{s.number}</span><span>{s.name}<small>{s.englishName}</small></span><span className="count">{s.numberOfAyahs}</span></button>)}</div>
        </aside>
        <article className="reader">
          <div className="reader-tools"><span>{t.font}</span><button onClick={()=>setFontSize(v=>Math.max(18,v-2))}>{t.smaller} −</button><button onClick={()=>setFontSize(v=>Math.min(40,v+2))}>{t.larger} +</button></div>
          {!surah && !loading && <div className="empty-state"><div>﷽</div><h3>{t.quran}</h3><p>اختر سورة من الفهرس لعرض آياتها</p></div>}
          {loading && <p className="notice">{t.loading}</p>}
          {error && <p className="notice error">{error}</p>}
          {surah && <><div className="surah-heading"><span>سورة</span><h2>{surah.name}</h2><small>{surah.revelationType === 'Meccan' ? 'مكية' : 'مدنية'} • {surah.numberOfAyahs} {t.ayah}</small></div><div className="verses" style={{fontSize}}>{surah.ayahs.map(a=><span key={a.numberInSurah}>{a.text} <span className="ayah-number">۞{a.numberInSurah}</span> </span>)}</div></>}
        </article>
      </section>
      <section className="feature-grid">
        <div id="recitations"><span>♫</span><h3>{t.recitations}</h3><p>استمع إلى التلاوات القرآنية.</p><small>سيُضاف مشغل الصوت واختيار القارئ في المرحلة التالية.</small></div>
        <div id="azan"><span>◷</span><h3>{t.azan}</h3><p>قسم الأذان ومواقيت الصلاة.</p><small>تُحدد المواقيت لاحقاً حسب المدينة.</small></div>
        <div id="adhkar"><span>✧</span><h3>{t.adhkar}</h3><p>الأذكار والأدعية اليومية.</p><small>سيُضاف محتوى موثّق في المرحلة التالية.</small></div>
      </section>
      <section className="contact" id="contact"><h2>{t.contact}</h2><p>للتواصل والاستفسارات، استخدم روابط صفحاتنا الاجتماعية.</p><div className="socials"><h3>{t.follow}</h3>{social.map(([name,icon,url])=><a key={name} href={url} target="_blank" rel="noreferrer"><b>{icon}</b>{name}</a>)}</div></section>
    </main>
    <footer>© {new Date().getFullYear()} {t.title} — جميع الحقوق محفوظة</footer>
  </div>;
}
createRoot(document.getElementById('root')).render(<App />);
